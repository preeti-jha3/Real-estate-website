var P=[
{id:1,t:"3 BHK high-rise apartment",loc:"Golf Course Road, Gurugram",type:"Apartment",mode:"buy",price:28500000,bd:3,ba:3,area:1850,tag:"Featured",h:196,am:["Clubhouse","Gym","Power backup","Covered parking","24x7 security"]},
{id:2,t:"Spacious 3 BHK with park view",loc:"Sector 150, Noida",type:"Apartment",mode:"buy",price:14500000,bd:3,ba:3,area:1620,tag:"Ready to move",h:160,am:["Swimming pool","Jogging track","Kids play area","EV charging"]},
{id:3,t:"Smart 2 BHK for first-time buyers",loc:"Greater Noida West",type:"Apartment",mode:"buy",price:6200000,bd:2,ba:2,area:1090,tag:"Best value",h:28,am:["Gym","Garden","Lift","Gated society"]},
{id:4,t:"Independent builder floor",loc:"Dwarka Sector 12, Delhi",type:"Builder Floor",mode:"buy",price:18000000,bd:3,ba:3,area:1500,tag:"New",h:262,am:["Stilt parking","Terrace","Modular kitchen","Metro nearby"]},
{id:5,t:"4 BHK luxury villa with lawn",loc:"Sohna Road, Gurugram",type:"Villa",mode:"buy",price:52000000,bd:4,ba:5,area:3400,tag:"Premium",h:340,am:["Private garden","Home theatre","Servant room","Solar panels"]},
{id:6,t:"Corner residential plot",loc:"Yamuna Expressway",type:"Plot",mode:"buy",price:4800000,bd:0,ba:0,area:1800,tag:"Clear title",h:96,am:["30m road","Park facing","Boundary wall","Water connection"]},
{id:7,t:"Furnished 2 BHK flat",loc:"Sector 62, Noida",type:"Apartment",mode:"rent",price:32000,bd:2,ba:2,area:1100,tag:"Furnished",h:180,am:["Metro nearby","AC in bedrooms","Wi-Fi ready","Parking"]},
{id:8,t:"Modern 1 BHK near Cyber Hub",loc:"DLF Phase 3, Gurugram",type:"Apartment",mode:"rent",price:28000,bd:1,ba:1,area:640,tag:"Near offices",h:215,am:["Semi furnished","Lift","24x7 water","Security"]},
{id:9,t:"Airy 3 BHK in a leafy colony",loc:"Vasant Kunj, Delhi",type:"Builder Floor",mode:"rent",price:85000,bd:3,ba:3,area:2100,tag:"Premium",h:300,am:["Balcony","Modular kitchen","Parking for 2","Park nearby"]},
{id:10,t:"Compact studio for professionals",loc:"Indirapuram, Ghaziabad",type:"Apartment",mode:"rent",price:16000,bd:1,ba:1,area:480,tag:"Low deposit",h:50,am:["Furnished","Lift","Power backup","Market nearby"]}];
/* ---- Photos (Unsplash). Replace any id with your own file, e.g. "images/home1.jpg" ---- */
function U(id,w){return /^(https?:|images\/)/.test(id)?id:"https://images.unsplash.com/"+id+"?auto=format&fit=crop&w="+(w||800)+"&q=70"}
function img(u){return u?'<img src="'+u+'" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="this.classList.add(\'loaded\')" onerror="this.remove()">':""}
function art(h,seed,hero,u){return svgArt(h,seed,hero)+img(u)}
function room(k,h){return roomSvg(k,h)+img(U(ROOMS[k]))}
var IM={1:"photo-1545324418-cc1a3fa10c00",2:"photo-1560448204-e02f11c3d0e2",3:"photo-1522708323590-d24dbb6b0267",4:"photo-1570129477492-45c003edd2be",5:"photo-1512917774080-9991f1c4c750",6:"photo-1500382017468-9049fed747ef",7:"photo-1502672260266-1c1ef2d93688",8:"photo-1493809842364-78817add7ffb",9:"photo-1564013799919-ab600027ffc6",10:"photo-1560185007-cde436f6a4d0"};
var ROOMS={living:"photo-1586023492125-27b2c045efd7",bed:"photo-1505693416388-ac5ce068fe85",kit:"photo-1556911220-e15b29be8c8f"},AREA=U("photo-1477959858617-67f85cf4f1df");
P.forEach(function(p){p.img=U(IM[p.id])});
var S={mode:"buy",bhk:0,fav:[],only:false},$=function(i){return document.getElementById(i)};
try{S.fav=JSON.parse(localStorage.getItem("nv-fav")||"[]")}catch(e){S.fav=[]}
function rnd(s){return function(){s=(s*9301+49297)%233280;return s/233280}}
function svgArt(h,seed,hero){var r=rnd(seed*7+3),o='<svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="g'+seed+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl('+h+',60%,78%)"/><stop offset="1" stop-color="hsl('+((h+30)%360)+',70%,92%)"/></linearGradient></defs><rect width="400" height="250" fill="url(#g'+seed+')"/><circle cx="'+(60+r()*280)+'" cy="55" r="22" fill="#f0a830" opacity=".85"/>';
var n=hero?7:5,x=-10,i;for(i=0;i<n;i++){var w=hero?60+r()*40:70+r()*40,bh=hero?90+r()*130:60+r()*100,y=250-bh;o+='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+bh+'" fill="hsl('+h+',45%,'+(22+r()*14)+'%)"/>';for(var wy=y+10;wy<246;wy+=16)for(var wx=x+8;wx<x+w-10;wx+=14)o+='<rect x="'+wx+'" y="'+wy+'" width="7" height="9" fill="'+(r()>.55?"#ffd98a":"rgba(255,255,255,.25)")+'"/>';x+=w+6}
return o+'<rect y="236" width="400" height="14" fill="hsl('+h+',30%,22%)"/></svg>'}
function money(p,m){if(m==="rent")return"₹"+p.toLocaleString("en-IN");return p>=1e7?"₹"+(p/1e7).toFixed(2).replace(/\.?0+$/,"")+" Cr":"₹"+(p/1e5).toFixed(0)+" L"}
function inr(n){return "₹"+Math.round(n).toLocaleString("en-IN")}
function emi(a,r,y){var m=r/1200,n=y*12;return a*m*Math.pow(1+m,n)/(Math.pow(1+m,n)-1)}
function toast(t){var e=$("toast");e.textContent=t;e.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(function(){e.classList.remove("on")},2600)}
function saveFav(){try{localStorage.setItem("nv-fav",JSON.stringify(S.fav))}catch(e){}$("savedCount").textContent=S.fav.length}
function budgets(){var b=S.mode==="buy"?[[0,"Any budget"],[10000000,"Up to ₹1 Cr"],[20000000,"Up to ₹2 Cr"],[30000000,"Up to ₹3 Cr"]]:[[0,"Any budget"],[20000,"Up to ₹20k"],[35000,"Up to ₹35k"],[60000,"Up to ₹60k"]];$("budget").innerHTML=b.map(function(x){return'<option value="'+x[0]+'">'+x[1]+"</option>"}).join("")}
function bhkChips(){$("bhk").innerHTML=[0,1,2,3,4].map(function(n){return'<button class="chip" data-b="'+n+'" aria-pressed="'+(S.bhk===n)+'" style="margin-right:6px">'+(n?n+"+ BHK":"Any BHK")+"</button>"}).join("")}
function render(){
  $("grid").classList.toggle("noanim",!!render.skip);render.skip=0;
  var q=$("q").value.trim().toLowerCase(),t=$("type").value,b=+$("budget").value,l=P.filter(function(p){return p.mode===S.mode&&(!t||p.type===t)&&(!b||p.price<=b)&&(!S.bhk||p.bd>=S.bhk)&&(!q||(p.loc+" "+p.t).toLowerCase().indexOf(q)>-1)&&(!S.only||S.fav.indexOf(p.id)>-1)});
  var s=$("sort").value;if(s==="lo")l.sort(function(a,b){return a.price-b.price});if(s==="hi")l.sort(function(a,b){return b.price-a.price});if(s==="area")l.sort(function(a,b){return b.area-a.area});
  $("count").textContent=l.length+(l.length===1?" home":" homes")+(S.mode==="buy"?" for sale":" for rent");
  $("grid").innerHTML=l.length?l.map(function(p,ix){var f=S.fav.indexOf(p.id)>-1;return'<article class="card" style="--i:'+ix+'" data-id="'+p.id+'" tabindex="0" aria-label="'+p.t+'"><div class="art">'+art(p.h,p.id,0,p.img)+'<span class="tag">'+p.tag+'</span><button class="fav" data-fav="'+p.id+'" aria-label="Save" aria-pressed="'+f+'">'+(f?"♥":"♡")+'</button></div><div class="body"><div class="price">'+money(p.price,p.mode)+(p.mode==="rent"?" <small>/month</small>":"")+'</div><h3>'+p.t+'</h3><div class="loc">'+p.loc+'</div><div class="specs"><span>'+(p.bd?p.bd+" bed":p.type)+'</span>'+(p.ba?"<span>"+p.ba+" bath</span>":"")+"<span>"+p.area.toLocaleString("en-IN")+" sq ft</span></div></div></article>"}).join(""):'<div class="empty"><b>No homes match these filters.</b><br>Try a higher budget or clear the area search.</div>'}
function roomSvg(k,h){var w="hsl("+h+",28%,88%)",f="hsl("+h+",22%,52%)",d="hsl("+h+",45%,30%)",l="hsl("+h+",40%,45%)",o='<svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice"><rect width="400" height="250" fill="'+w+'"/><rect y="175" width="400" height="75" fill="'+f+'"/><rect y="172" width="400" height="5" fill="hsl('+h+',20%,40%)"/>';
if(k==="living")o+='<rect x="30" y="30" width="120" height="100" fill="#cfe8f5" stroke="#fff" stroke-width="6"/><path d="M90 30v100M30 80h120" stroke="#fff" stroke-width="4"/><rect x="180" y="140" width="180" height="55" rx="10" fill="'+d+'"/><rect x="172" y="120" width="196" height="36" rx="10" fill="'+l+'"/><rect x="195" y="132" width="40" height="26" rx="6" fill="#f0a830"/><rect x="60" y="200" width="110" height="30" rx="4" fill="hsl('+h+',30%,75%)"/><rect x="210" y="40" width="90" height="60" fill="hsl('+h+',40%,70%)" stroke="#fff" stroke-width="4"/><rect x="372" y="110" width="6" height="70" fill="#333"/><circle cx="375" cy="104" r="14" fill="#ffd98a"/>';
if(k==="bed")o+='<rect x="250" y="30" width="110" height="90" fill="#cfe8f5" stroke="#fff" stroke-width="6"/><rect x="60" y="70" width="190" height="60" rx="6" fill="'+d+'"/><rect x="50" y="120" width="210" height="70" rx="8" fill="#fff"/><rect x="50" y="150" width="210" height="40" fill="'+l+'"/><rect x="70" y="108" width="60" height="22" rx="8" fill="#f4f4f4"/><rect x="150" y="108" width="60" height="22" rx="8" fill="#f4f4f4"/><rect x="280" y="150" width="50" height="50" fill="'+d+'"/><circle cx="305" cy="138" r="12" fill="#ffd98a"/>';
if(k==="kit")o+='<rect x="20" y="30" width="360" height="60" fill="'+d+'"/><path d="M110 30v60M200 30v60M290 30v60" stroke="'+w+'" stroke-width="2"/><rect x="20" y="120" width="360" height="60" fill="'+l+'"/><rect x="20" y="112" width="360" height="10" fill="#f4f4f4"/><circle cx="80" cy="108" r="8" fill="#222"/><circle cx="110" cy="108" r="8" fill="#222"/><rect x="150" y="100" width="6" height="12" fill="#999"/><rect x="130" y="195" width="140" height="22" fill="#f4f4f4"/><circle cx="150" cy="232" r="10" fill="#f0a830"/><circle cx="250" cy="232" r="10" fill="#f0a830"/>';
return o+"</svg>"}
function views(p){var v=[["Exterior",art(p.h,p.id,0,p.img)]];if(p.type!=="Plot")v.push(["Living",room("living",p.h)],["Bedroom",room("bed",p.h)],["Kitchen",room("kit",p.h)]);v.push(["Area view",art(p.h+20,p.id+50,0,AREA)]);return v}
function open(id){
  var p=P.filter(function(x){return x.id===id})[0],buy=p.mode==="buy",e=buy?emi(p.price*.8,8.5,20):0;
  $("dBody").innerHTML='<div class="m-art" id="mArt">'+art(p.h,p.id,0,p.img)+'</div><div class="thumbs" id="thumbs">'+views(p).map(function(v,i){return'<button type="button" data-v="'+i+'" aria-pressed="'+(i===0)+'"><i>'+v[1]+'</i>'+v[0]+'</button>'}).join("")+'</div><div class="m-body"><div><div class="price">'+money(p.price,p.mode)+(buy?"":" <small>/month</small>")+'</div><h2 style="font-size:26px;margin:6px 0">'+p.t+'</h2><div class="loc">'+p.loc+'</div><div class="specs"><span>'+(p.bd?p.bd+" bed":p.type)+"</span>"+(p.ba?"<span>"+p.ba+" bath</span>":"")+"<span>"+p.area.toLocaleString("en-IN")+" sq ft</span></div><div class=\"am\">"+p.am.map(function(a){return"<span>"+a+"</span>"}).join("")+"</div>"+(buy?'<p class="loc">With 20% down payment at 8.5% for 20 years, your EMI is about <b style="color:var(--ink)">'+inr(e)+"/month</b>.</p>":'<p class="loc">Security deposit: 2 months rent. Zero brokerage.</p>')+'</div><form class="form" id="enq" novalidate><b>Book a visit</b><input id="eN" placeholder="Your name" autocomplete="name"><input id="eP" placeholder="10-digit mobile number" inputmode="numeric" autocomplete="tel"><textarea id="eM" rows="2" placeholder="Preferred day and time"></textarea><div class="err" id="eE"></div><button class="btn alt" type="submit">Request a visit</button></form></div>';
  $("dlg").showModal();
  $("thumbs").onclick=function(e){var b=e.target.closest("[data-v]");if(!b)return;$("mArt").innerHTML=views(p)[+b.dataset.v][1];this.querySelectorAll("button").forEach(function(x){x.setAttribute("aria-pressed",x===b)})};
  $("enq").onsubmit=function(ev){ev.preventDefault();var n=$("eN").value.trim(),ph=$("eP").value.replace(/\D/g,"");if(n.length<2){$("eE").textContent="Enter your name.";return}if(!/^[6-9]\d{9}$/.test(ph)){$("eE").textContent="Enter a valid 10-digit Indian mobile number.";return}$("dlg").close();toast("Visit requested, "+n.split(" ")[0]+". We will call you within a day.")}}
function calc(){var a=+$("lAmt").value,r=+$("lRate").value,y=+$("lYrs").value,e=emi(a,r,y);$("vAmt").textContent=inr(a);$("vRate").textContent=r.toFixed(1)+"%";$("vYrs").textContent=y+" years";$("rEmi").textContent=inr(e);$("rInt").textContent=inr(e*y*12-a);$("rTot").textContent=inr(e*y*12)}
$("heroArt").innerHTML=art(196,99,true,U("photo-1545324418-cc1a3fa10c00",1100));
document.querySelectorAll(".tabs button").forEach(function(b){b.onclick=function(){S.mode=b.dataset.mode;document.querySelectorAll(".tabs button").forEach(function(x){x.setAttribute("aria-pressed",x===b)});budgets();render()}});
$("finder").onsubmit=function(e){e.preventDefault();render();$("listings").scrollIntoView()};
$("bhk").onclick=function(e){var b=e.target.closest("[data-b]");if(!b)return;S.bhk=+b.dataset.b;bhkChips();render()};
["budget","sort","type"].forEach(function(i){$(i).onchange=render});$("q").oninput=render;
$("onlySaved").onclick=function(){S.only=!S.only;this.setAttribute("aria-pressed",S.only);render()};
$("grid").onclick=function(e){var f=e.target.closest("[data-fav]");if(f){e.stopPropagation();var id=+f.dataset.fav,i=S.fav.indexOf(id);i>-1?S.fav.splice(i,1):S.fav.push(id);saveFav();render.skip=1;render();return}var c=e.target.closest(".card");if(c)open(+c.dataset.id)};
$("grid").onkeydown=function(e){if(e.key==="Enter"&&e.target.classList.contains("card"))open(+e.target.dataset.id)};
$("dClose").onclick=function(){$("dlg").close()};$("dlg").onclick=function(e){if(e.target===this)this.close()};
["lAmt","lRate","lYrs"].forEach(function(i){$(i).oninput=calc});
$("theme").onclick=function(){var r=document.documentElement,d=r.dataset.theme?r.dataset.theme==="dark":matchMedia("(prefers-color-scheme:dark)").matches;r.dataset.theme=d?"light":"dark"};
budgets();bhkChips();saveFav();render();calc();

/* ---- Transitions, popups, help ---- */
var io="IntersectionObserver" in window?new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12}):null;
document.querySelectorAll(".hero .wrap>*,section .bar,.emi,.contact-grid .cc,.faq details").forEach(function(el,i){el.classList.add("rv");el.style.transitionDelay=(i%4)*70+"ms";io?io.observe(el):el.classList.add("in")});
addEventListener("scroll",function(){document.querySelector("nav").classList.toggle("sc",scrollY>8)},{passive:true});
function validPhone(v){return /^[6-9]\d{9}$/.test(v.replace(/\D/g,""))}
function openD(id){var d=$(id);if(!document.querySelector("dialog[open]"))d.showModal()}
document.querySelectorAll("dialog").forEach(function(d){d.addEventListener("close",function(){d.classList.remove("out")});if(d.id!=="dlg")d.addEventListener("click",function(e){if(e.target===d)d.close()})});
document.querySelectorAll("[data-close]").forEach(function(b){b.onclick=function(){b.closest("dialog").close()}});
$("helpFab").onclick=function(){openD("hlp")};
$("hlpFaq").onclick=function(){$("hlp").close();$("help").scrollIntoView()};
$("navHelp").onclick=function(e){e.preventDefault();$("help").scrollIntoView()};
$("alertForm").onsubmit=function(e){e.preventDefault();if(!validPhone($("aP").value)){$("aE").textContent="Enter a valid 10-digit Indian mobile number.";return}$("wel").close();toast("You are on the list. We will send matching homes soon.")};
var seen=0;try{seen=sessionStorage.getItem("nv-wel")}catch(e){}
if(!seen)setTimeout(function(){openD("wel");try{sessionStorage.setItem("nv-wel","1")}catch(e){}},4500);
